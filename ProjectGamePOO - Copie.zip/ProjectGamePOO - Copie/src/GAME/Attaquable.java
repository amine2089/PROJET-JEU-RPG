package GAME;

public interface Attaquable {
	void attaquer(Personnage cible);
	void utiliserCompetence(Personnage cible);
   void gagnerpointsdevie(int HP) ;
		
		
	
}
