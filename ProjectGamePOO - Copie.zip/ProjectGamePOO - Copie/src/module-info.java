/**
 * 
 */
/**
 * 
 */
module ProjectGamePOO {
	requires java.desktop;
}